<?php
/**
 * Copyright 1999-2017. Plesk International GmbH.
 */

pm_Context::init('welcome-wp');

$application = new pm_Application();
$application->run();
